package com.javaprogram.project;

public class Book {
	/*create instance variables **/

    public static String Book_title; 
    public static String Book_Price;

    /* create a constructor that allows a user to input instance variables **/
    public Book(String book_title, String book_price) {
		super();
		Book_title = book_title;
		Book_Price = book_price;
	}

	public static String getBook_title() {
		return Book_title;
	}


	public void setBook_title(String book_title) {
		Book_title = book_title;
	}
	public String getBook_Price() {
		return Book_Price;
	}
	public void setBook_Price(String book_Price) {
		Book_Price = book_Price;
	}

	public Book[] create_books() {
		Book[] books = new Book[2];
        books[0] = new Book("Java Programming", "Rs.350.50");
        books[1] = new Book("Let US C", "Rs.200.09");
		
		return books;        
  
       
	}
	
    public String show_Books()
    {
    	
    		return "The details of the book are: " + Book_title + ", " + Book_Price ;
		
    }
    
    public static void main(String[] args) {
		
    	Book books= new Book(Book_title, Book_Price);
    	books.create_books();
    	books.show_Books();
    	System.out.println(books.show_Books());
    	
    	
 
	}
    
}



