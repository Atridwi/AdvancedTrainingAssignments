package com.bookstore.entity;

import java.sql.Timestamp;

public class Orders {
	
	int order_id;
	String address;
	int Phone_no;
	String name;
	Timestamp orderdate;
	int quantity;
	
	public Orders(String address, int mobileno, String name) {
		super();
		this.address = address;
		this.Phone_no = mobileno;
		this.name = name;
	}
	public Orders(int order_id, String address, int mobileno, String name,int quantity) {
		super();
		this.order_id = order_id;
		this.address = address;
		this.Phone_no = mobileno;
		this.name = name;
		this.quantity = quantity;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public int getPhone_no() {
		return Phone_no;
	}
	public void setPhone_no(int phone_no) {
		Phone_no = phone_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Timestamp getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Timestamp orderdate) {
		this.orderdate = orderdate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Orders [order_id=" + order_id + ", address=" + address + ", mobileno=" + Phone_no + ", name=" + name
				+ ", orderdate=" + orderdate + ", quantity=" + quantity + "]";
	}

	
	

}

